#include <iostream>
#include <cmath>


 using namespace std;

 int main(){

     int n,  a = 1;

     cout << "Program that prints out the multiplication table till 12" << endl;
     cout<<"Enter the number you want to see its multiplication table"<<endl;
     cin >> n;

     for (a = 1; a<=12; a++)
    cout<< n << "* "<< a << "="<< a*n <<endl;  

         return 0;}
