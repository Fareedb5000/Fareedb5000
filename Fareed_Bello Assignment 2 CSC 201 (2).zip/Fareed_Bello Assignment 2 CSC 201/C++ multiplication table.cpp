#include <iostream>
using namespace std;

int main()
{
    int a, b, n;

    cout << "Program that shows the multiplication table of a given number:"<<endl;
    cout << "-------------------------------------------------------------"<<endl;
    cout << "Input the number "<< endl;
    cin >> n;

    cout << "Multiplication table from 1 to " << n << endl;
    for (a = 1; a <= n; a++)
    {
        for (b = 1; b <= n; b++)
        {
            if (b <= n )
                cout << a << " x " << b << " = "<< a * b<<" ";

        }
        cout << "\n";

    }
    cout <<"_____________________________________________________________________________________________________"<<endl;
return 0;}
