#include <iostream>
using namespace std;

int main()
{

    int up,low, i, r, num;
    int sum = 0;

    cout << "Enter the upper limit"<<endl;
    cin >> up;
    cout<< " Enter the lower Limit" << endl;
    cin >> low;
    cout << "\n the odd numbers between " << up << " and " << low << " are"<<endl;
    for (i = (up+1); i <= low; i++)
    {
        r = i % 2;
        if (r == 1)
            cout << "\n"
                 << i<<endl;
    }
    for (num = up; num <= low; num++)
        if (num % 2 != 0)
            sum = sum + num;

    cout << "Sum of odd numbers between "<<up<< " and "<<low<< " is: " << sum;
    return 0;
}
